save_directory = "/Users/user/Downloads/"
max_concurrent_downloads = 3
